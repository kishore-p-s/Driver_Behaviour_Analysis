package com.example.carmodel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
